"use strict";

var vault = null, qrtext = null;

$(document).ready(function() {
	chrome.runtime.getBackgroundPage(function(bg) {
		vault = bg.vault;
		setup();
	});
});

function notifyVaultChange() {
	// Not required for Chrome
}